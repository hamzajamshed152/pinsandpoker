<?php

namespace App\Constants;

class RoleType {

    const PLAYER = 'user';
    const MODERATOR = 'moderator';
    const ADMIN = 'admin';
    
}