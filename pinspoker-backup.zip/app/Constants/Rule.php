<?php

namespace App\Constants;

class Rule {

    const GENERAL = 'general';
    const SPECIAL = 'special';

}